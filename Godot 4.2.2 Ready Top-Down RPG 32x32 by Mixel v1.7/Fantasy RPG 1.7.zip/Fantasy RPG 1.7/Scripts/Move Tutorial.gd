extends Node2D

@onready var tutorial = $"."

var t := 0.0
@export var float_strength := 2.0
@export var float_speed := 2.0

func _process(delta):
	t += delta
	position.y += sin(t * float_speed) * float_strength * delta

func _input(event):
	if event.is_action_pressed("Toggle Tutorials"):
		toggle_tutorials()

func toggle_tutorials():
	if tutorial.visible:
		tutorial.hide()
	else:
		tutorial.show()
