extends Control

@onready var menu = $"Main Menu"
@onready var settings = $Settings

#States of MENU
enum MenuState {
	NONE,
	MAIN,
	SETTINGS,
	LOADGAME
}
var current_state = MenuState.NONE




#Main Menu Buttons

#Save Game Button - missing func
#Load Game Button - missing func

#Open/Close Main Menu
func _input(event):
	if event.is_action_pressed("ui_cancel"):
		toggle_menu()

#Check for the current state of the menu. If its closed = open, if its open = close when the ESC is pressed.
func toggle_menu():
	if current_state == MenuState.NONE:
		open_main_menu()
	else:
		close_menu()

#Main Menu was closed so it opens.
func open_main_menu():
	menu.show()
	settings.hide()
	#load_menu.hide()

	current_state = MenuState.MAIN
	get_tree().paused = true

#Close Main menu when ESC is pressed while it was open
func close_menu():
	menu.hide()
	settings.hide()
	#load_menu.hide()

	current_state = MenuState.NONE
	get_tree().paused = false

#Settings Button
func _on_settings_pressed():
	menu.hide()
	settings.show()

	current_state = MenuState.SETTINGS

#Exit Button
func _on_button_exit_game_pressed():
	get_tree().quit()




#Settings Menu Buttons

#HUD Button - missing func
#Audio Button - missing func
#Graphics Button - missing func

#Back Button
func _on_back_button_pressed():
	if current_state == MenuState.SETTINGS:
		menu.show()
		settings.hide()
		current_state = MenuState.MAIN


