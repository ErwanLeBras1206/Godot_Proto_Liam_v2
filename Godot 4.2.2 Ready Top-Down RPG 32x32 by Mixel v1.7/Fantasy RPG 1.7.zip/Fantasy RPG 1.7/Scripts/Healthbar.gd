extends Control

@onready var health_bar = $TextureProgressBar

var max_health = 100
var current_health = 100

func _ready():
	health_bar.value = current_health

func take_damage(amount: int):
	current_health = clamp(current_health - amount, 0, max_health)
	health_bar.value = current_health
