extends CanvasLayer

@onready var menu = $Menus/PauseMenu
@onready var inventory = $Menus/Inventory




func _process(delta):
	if Input.is_action_just_pressed("inventory"):
		open_close_inventory()
	#if Input.is_action_just_pressed("ui_cancel"):
		#main_menu_open_close()
#
#
#func main_menu_open_close():
	#menu.visible = !menu.visible
	#get_tree().paused = menu.visible

func open_close_inventory():
	inventory.visible = !inventory.visible
