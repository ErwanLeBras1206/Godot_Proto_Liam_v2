extends Control

@onready var inventory = $"."


func _on_button_close_pressed():
	if inventory.visible:
		inventory.visible = false
